export type AmplifyDependentResourcesAttributes = {
  "api": {
    "register123": {
      "GraphQLAPIEndpointOutput": "string",
      "GraphQLAPIIdOutput": "string",
      "GraphQLAPIKeyOutput": "string"
    }
  }
}